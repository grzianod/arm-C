#include <math.h>
extern int check_square(int*, int*, int);
extern float my_division(float*, float*);
extern int _Matrix_Coordinates[11][22];
extern char _ROWS;
extern char _COLUMNS;

typedef enum {FALSE, TRUE} boolean;

int main(void){
		float	r=5.0, area=0.0;
		volatile float pi_greco;
		volatile boolean result;
	
		for(int i=0;i<_ROWS; i++) {
			for(int j=0; j<_COLUMNS; j+=2) {
				result = check_square(&(_Matrix_Coordinates[i][j]),&(_Matrix_Coordinates[i][j+1]),r);
				if(result == TRUE)
					area+=result;
			}
		}
		r=pow(r,2);
		pi_greco = my_division(&area, &r);
		__asm__("SVC 0xCA");
		__asm__("SVC 0xFE");
		while(1);
}

